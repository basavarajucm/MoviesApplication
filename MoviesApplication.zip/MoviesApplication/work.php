<?php
session_start();
include('serverconnect.php');


	$mvid = $_GET['mveid'];
	
	//echo $mvid;
//print_r($_SESSION);
	
	$query="select movie_title,movie_yor,movie_plot,movie_poster,actor_name,actor_sex,actor_dob, actor_bio,producer_name, producer_sex, producer_dob, producer_bio from movies m, actor a, producer p where m.movie_Id = '$mvid' AND m.movie_Id = a.movie_id AND m.movie_id = p.producer_movie_id";
	
	$sql_query=mysqli_query($conn, $query);
	
	
?>

<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Movies Application</title>
	<link rel="shortcut icon" href="favicon.ico">
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
	

 
  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<link rel="shortcut icon" href="favicon.ico">

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,300,600,400italic,700' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Owl Carousel -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">
	
	<link rel="stylesheet" href="css/style.css">

	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet">
	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
<style>
h1{
	font-size:25px !important;
}
.c1{
	color:blue !important;
}
</style>
	</head>
	<body>

	<div id="fh5co-page">
		<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle"><i></i></a>
		<aside id="fh5co-aside" role="complementary" class="border js-fullheight">

			<h1 id="fh5co-logo"><a href="index.php"><img src="images/Movie_Central.png"  height="62px" alt="not found"></a></h1>
			<nav id="fh5co-main-menu" role="navigation">
				<ul>
				    <li class="fh5co-active"><a href="index.php">Movies List</a></li>
					<li><a href="addmovies.php">Add Movies</a></li>
				</ul>
			</nav>

			

		</aside>
    
		<div id="fh5co-main">
          
             
			<div class="fh5co-narrow-content editmain">
				<div class="row">
                   <?php
				   while($row = mysqli_fetch_array($sql_query))
	               {
		
	              ?>
					<div class="col-md-12 animate-box" data-animate-effect="fadeInLeft">
						<figure class="text-center">
						<?php echo '<img src="data:image;base64,'.$row['movie_poster'].'" alt="Poster Image Not Found" style="width:100%;height:100%">'?>
						</figure>
					</div>
				<div class="row" style="float:right">	
				<div class="col-sm-12">
				  <label style="color:red;font-size:30px;">Movie Details</label>
				</div>
					  
				 </div>
				
				<div class="row work-pagination animate-box" data-animate-effect="fadeInLeft">
			
					<div class="col-md-6">
					 <?php echo '<h1><span class="c1">Movie title:</span>'.$row['movie_title'].'</h1>';?>
					</div>
					<div class="col-md-6">
					<?php echo '<h1><span class="c1">Year Of Relase:</span>'.$row['movie_yor'].'</h1>';?>
					</div>
					<div class="col-md-6">
					<?php echo '<h1><span class="c1">Movie Plot:</span>'.$row['movie_plot'].'</h1>';?>
					</div>
					<div class="col-md-12">
					  &nbsp
					</div>
				</div>
				<label style="color:red;font-size:30px;">Actor Details</label>
				<div class="row work-pagination animate-box" data-animate-effect="fadeInLeft">
					<div class="col-md-6">
					<?php echo '<h1><span class="c1">Actor Name:</span><span style="font-size:20px;">'.$row['actor_name'].'</span></h1>';?>
					</div>
					<div class="col-md-6">
					<?php echo '<h1><span class="c1">Actor DOB:</span>'.$row['actor_dob'].'</h1>';?>
					</div>
					<div class="col-md-6">
					<?php echo '<h1><span class="c1">Actor Sex:</span>'.$row['actor_sex'].'</h1>';?>
					</div>
					<div class="col-md-6">
					<?php echo '<h1><span class="c1">Actor Biography:</span><span style="font-size:20px;">'.$row['actor_bio'].'</span></h1>';?>
					</div>
			  </div>
			  
			   <label style="color:red;font-size:30px;">Producer Details</label>
				<div class="row work-pagination animate-box" data-animate-effect="fadeInLeft">
					<div class="col-md-6">
					<?php echo '<h1><span class="c1">Producer Name:</span>'.$row['producer_name'].'</h1>';?>
					</div>
					<div class="col-md-6">
					<?php echo '<h1><span class="c1">Producer DOB:</span>'.$row['producer_dob'].'</h1>';?>
					</div>
					<div class="col-md-6">
					<?php echo '<h1><span class="c1">Producer Sex:</span>'.$row['producer_sex'].'</h1>';?>
					</div>
					<div class="col-md-6">
					<?php echo '<h1><span class="c1">Producer Biography:</span>'.$row['producer_bio'].'</h1>';?>
					</div>
					
				</div>
				<div class="col-sm-6">
				
				    <form action="editmovies.php" method="post">
					 <input type="hidden" name="mve_title" value="<?php echo $row['movie_title'] ?>">
					  <input type="hidden" name="mve_yor" value="<?php echo $row['movie_yor'] ?>">
					   <input type="hidden" name="mve_plot" value="<?php echo $row['movie_plot'] ?>">
					   
					    <input type="hidden" name="actor_name" value="<?php echo $row['actor_name'] ?>">
						 <input type="hidden" name="actor_sex" value="<?php echo $row['actor_sex'] ?>">
						  <input type="hidden" name="actor_dob" value="<?php echo  $row['actor_dob'] ?>">
						   <input type="hidden" name="actor_bio" value="<?php echo  $row['actor_bio'] ?>">
						   
						    <input type="hidden" name="producer_name" value="<?php echo $row['producer_name'] ?>">
							 <input type="hidden" name="producer_sex" value="<?php echo $row['producer_sex'] ?>">
							  <input type="hidden" name="producer_dob" value="<?php echo $row['producer_dob'] ?>">
							   <input type="hidden" name="producer_bio" value="<?php echo $row['producer_bio']?>">
					 
				               <input type="hidden" name="mve_id" value="<?php echo $mvid ?>">
				      <input type="submit" class="btn btn-primary edit" value="Edit Movie Details"/>
				</div>
			
				</div>
			<?php } ?>
				

			</div>
			
			
	
		
			
		</div>
	</div>

	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- Stellar -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Counters -->
	<script src="js/jquery.countTo.js"></script>
	
	
	<!-- MAIN JS -->
	<script src="js/main.js"></script>
	
	


	</body>
</html>

