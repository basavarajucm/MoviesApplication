<?php
include('serverconnect.php');
if(isset($_POST['submit']))
 {
	  
     if(getimagesize($_FILES['poster']['tmp_name'])== FALSE) 
	 {
		
               echo "<script type='text/javascript'>alert('Please select Valid Poster Image')
			   window.location.href='index.php';
			   </script>";
             
			
	 }
	 else
	 {
		 $title = $_POST['title'];
		// echo $title;
		 $releaseDate =$_POST['releaseDate'];
		 //echo $releaseDate;
		 $plot =$_POST['plot'];
		// echo $plot;
		 $mve_id=$_POST['mve_id'];
		 //echo $mve_id;
		 
	
		 $poster= addslashes($_FILES['poster']['tmp_name']);
		 $name= addslashes($_FILES['poster']['name']);
		 $poster= file_get_contents($poster);
		 $poster= base64_encode($poster);
		 
		// echo $poster;
		
		//updatingb movie
		
		$query= "UPDATE movies SET movie_title='$title', movie_yor='$releaseDate', movie_plot='$plot', movie_poster='$poster' WHERE movie_Id='$mve_id'";
		$sql_query = mysqli_query($conn,$query);
		
		
        
		 $actor = $_POST['actor'];
		 //echo $actor;
		 
		 $actorDOB = $_POST['actorDOB'];
		 //echo $actorDOB;
		 
		 $actorsex = $_POST['actorGender'];
		 //echo $actorsex;
		 
		 $actorBIO = $_POST['actorBIO'];
		 //echo $actorBIO;
		 
	    $query ="UPDATE actor SET actor_name='$actor', actor_sex='$actorsex', actor_dob='$actorDOB', actor_bio='$actorBIO' WHERE movie_id='$mve_id'";
		$sql_query = mysqli_query($conn,$query);
		
		 
		 $producer = $_POST['producer'];
		 //echo $producer;
		 $producerDOB = $_POST['producerDOB'];
		 //echo $producerDOB;
		 $producersex = $_POST['producersex'];
		 //echo $producersex;
		 $producerBIO = $_POST['producerBIO'];
		 //echo $producerBIO;
		 
		 $query ="UPDATE producer SET producer_name='$producer', producer_sex='$producersex', producer_dob='$producerDOB', producer_bio='$producerBIO' WHERE producer_movie_id='$mve_id'";
		$sql_query = mysqli_query($conn,$query);
		if($sql_query)
		{
			 echo "<script type='text/javascript'>confirm('Movie Updated Successfully');
			         window.location.href='index.php';
			   </script>";
             
		}
		else
		{
			 echo "<script type='text/javascript'>confirm('Something went wrong please try agin later!!');
			         window.location.href='index.php';
			   </script>";
		} 
		 
	 }
 }

?> 