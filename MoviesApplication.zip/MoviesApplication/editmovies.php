<?php
include('serverconnect.php');

if($_SERVER["REQUEST_METHOD"] == "POST")
	{
	$mvid = $_POST['mve_id'];
	$mve_title= $_POST['mve_title'];
	$mve_yor = $_POST['mve_yor'];
	$mve_plot = $_POST['mve_plot'];
	
	$actor_name = $_POST['actor_name'];
	$actor_sex = $_POST['actor_sex'];
	$actor_dob = $_POST['actor_dob'];
	$actor_bio = $_POST['actor_bio'];
	
	$producer_name = $_POST['producer_name'];
	$producer_sex = $_POST['producer_sex'];
	$producer_dob = $_POST['producer_dob'];
	$producer_bio = $_POST['producer_bio'];
	}
	
	
	
?>



<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Movies App</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="movies app" />
	<meta name="keywords" content="movies app" />
	<meta name="author" content="movies app" />

 

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<link rel="shortcut icon" href="favicon.ico">
	<link rel="icon" type="image/png" href="images/icons/favicon.ico"/>
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/bootstrap/css/bootstrap.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animate/animate.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/css-hamburgers/hamburgers.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/animsition/css/animsition.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/select2/select2.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="vendor/daterangepicker/daterangepicker.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">

	<link href='https://fonts.googleapis.com/css?family=Roboto:400,300,600,400italic,700' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet' type='text/css'>
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Owl Carousel -->
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<link rel="stylesheet" href="css/owl.theme.default.min.css">
	<!-- Theme style  -->
	<link rel="stylesheet" href="css/style.css">

	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
<style>
.alert {
    padding: 20px;
   
    color: white;
}

.closebtn {
    margin-left: 15px;
    color: white;
    font-weight: bold;
    float: right;
    font-size: 22px;
    line-height: 20px;
    cursor: pointer;
    transition: 0.3s;
}

.closebtn:hover {
    color: black;
}
</style>
	</head>
	<body>

	<div id="fh5co-page">
		<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle"><i></i></a>
		<aside id="fh5co-aside" role="complementary" class="border js-fullheight">

			<h1 id="fh5co-logo"><a href="index.html"><img src="images/Movie_Central.png"  height="62px" alt="not found"></a></h1>
			<nav id="fh5co-main-menu" role="navigation">
				<ul>
					<li><a href="index.php">Movies List</a></li>
					<li class="fh5co-active"><a href="addmovies.php">Add Movies</a></li>
				<!--<li><a href="addActors.php">Add Actors</a></li>
					<li><a href="addProducers.php">Add Producers</a></li> -->
				</ul>
			</nav>


		</aside>
		<div id="fh5co-main">
		   <div class="container-contact100 editdetails">
			<div class="wrap-contact100">
			<form  method="post" action="update_movies.php" class="contact100-form validate-form"  enctype="multipart/form-data">
				<span class="contact100-form-title">
				  Edit MOVIE Details
				</span>
				<input type="hidden" value="<?php echo $mvid ?>" name="mve_id"/>
                 <label>Name</label>
				<div class="wrap-input100 validate-input">
					<input class="input100" id="name" type="text" name="title" value="<?php echo $mve_title ?>" required>
					<label class="label-input100" for="name">
						<span><i class="fa fa-film" aria-hidden="true"></i></span>
					</label>
				</div>

				<label>Date Of Release</label>
				<div class="wrap-input100 validate-input">
					<input class="input100" id="datepicker" type="text" name="releaseDate" value="<?php echo $mve_yor ?>" required >
					<label class="label-input100" for="releaseDate">
						<span><i class="fa fa-calendar" aria-hidden="true"></i></span>
					</label>
				</div>
				
				
				<label>Poster Image</label>
				<div class="wrap-input100 validate-input">
				<span>Poster Image</span>
					<input class="input100" id="poster" type="file" name="poster" placeholder="Image size should be less then 2MB" required>
					
					<span style="color:green">Please Upload Only Images</span>
				</div>
				
				<label>Movie Plot</label>
				<div class="wrap-input100 validate-input">
					<input class="input100" name="plot" placeholder="Plot..." value="<?php echo $mve_plot ?>" required>
				</div>
				
				<!--adding actors 
				<div class="contact100-form-checkbox">
					<input class="input-checkbox100" id="addactors" type="checkbox" name="addingactor" value="addingactor">
					<label class="label-checkbox100" for="addactors">
						Would to Like to add Actors for this movie
					</label>
				</div>-->
           <label style="color:red;font-size:20px">Actor Details</label>
				<div class="actor">	
				
				<label>Name</label>
				<div class="wrap-input100 validate-input" >
					<input class="input100 mveactor" id="actor" type="text" name="actor" value="<?php echo $actor_name ?>" required>
					<label class="label-input100" for="actor">
						<span><i class="fa fa-male" aria-hidden="true"></i></span>
					</label>
				</div>
			
				<label>Gender</label>  
				<div class="wrap-input100 validate-input">
				    <span style="font-weight:bold">Select Gender:</span>
					<input id="sex" type="radio" name="actorGender" value="Male" required>Male
					<input  id="sex" type="radio" name="actorGender" value="FeMale">Female
				</div>
				
				<label>Date of Birth</label>
				<div class="wrap-input100 validate-input">
					<input class="input100 mveactor" id="datepicker1" type="text" name="actorDOB" value="<?php echo $actor_dob ?>" required>
					<label class="label-input100" for="actorDOB">
						<span><i class="fa fa-calendar" aria-hidden="true"></i></span>
					</label>
				</div>
				
				<label>Biography</label>
				<div class="wrap-input100 validate-input">
					<input class="input100 mveactor" name="actorBIO" value="<?php echo $actor_bio ?>" required>
				</div>
			</div>	
				
			<!-- adding producers
			<div class="contact100-form-checkbox">
					<input class="input-checkbox100" id="addproducers" type="checkbox" name="addingproducer" value="addingproducer">
					<label class="label-checkbox100" for="addproducers">
						Would to Like to add Producer for this movie
					</label>
			</div>-->
			   <label style="color:red;font-size:20px">Producer Details</label>
			<div class="producer">	
			    <label>Name</label>
				<div class="wrap-input100 validate-input">
					<input class="input100" id="producer" type="text" name="producer" value="<?php echo $producer_name ?>" required>
					<label class="label-input100" for="producer">
						<span><i class="fa fa-male" aria-hidden="true"></i></span>
					</label>
				</div>
				
				 <label>Gender</label>
				<div class="wrap-input100 validate-input" style="display:flex;flex-direction:column;">
				    <span style="font-weight:bold">Select Gender:</span>
					<span style="margin-left:18px"><input id="sex" type="radio" name="producersex" value="Male" required>Male
					<input  id="sex" type="radio" name="producersex" value="FeMale">Female</span>
					
				</div>
				
				 <label>date of birth</label>
				<div class="wrap-input100 validate-input">
					<input class="input100" id="datepicker2" type="text" name="producerDOB" value="<?php echo $producer_dob ?>" required>
					<label class="label-input100" for="ProducerDOB">
						<span><i class="fa fa-calendar" aria-hidden="true"></i></span>
					</label>
				</div>
				
				 <label>Name</label>
				<div class="wrap-input100 validate-input">
					<input class="input100" name="producerBIO" value="<?php echo $producer_bio ?>" required>
					
				</div>
			</div>		

				<div class="container-contact100-form-btn">
					<div class="wrap-contact100-form-btn">
						<div class="contact100-form-bgbtn"></div>
						<button class="contact100-form-btn" type="submit" name="submit">Update Movie</button>
							
					</div>
					
				</div>
				<div class="alert messagebox" style="margin-top:22px">
                       <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
                      
                </div>
			</form>
		</div>
		
		</div>
		
		
		</div>
	</div>	
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- Stellar -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Counters -->
	<script src="js/jquery.countTo.js"></script>
	
	<div id="dropDownSelect1"></div>

<!--===============================================================================================-->
	<script src="vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/bootstrap/js/popper.js"></script>
	<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/select2/select2.min.js"></script>
<!--===============================================================================================-->
	<script src="vendor/daterangepicker/moment.min.js"></script>
	<script src="vendor/daterangepicker/daterangepicker.js"></script>
<!--===============================================================================================-->
	<script src="vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================
	<script src="js/main.js"></script>-->
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
 
  <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-23581568-13"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-23581568-13');
</script>
 <script>
  $( function() {
    $( "#datepicker" ).datepicker();
	$( "#datepicker1" ).datepicker();
	$( "#datepicker2" ).datepicker();
  } );
  </script>
 
</body>
</html>	
